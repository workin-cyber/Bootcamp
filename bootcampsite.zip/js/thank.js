(function ($) {

    $(".single_price_plan").click(function(){
        debugger;
        var sub=$(this).data("sub");
        window.open('http://'+sub+'.workin.co.il',)
    })


})(jQuery);